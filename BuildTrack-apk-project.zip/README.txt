HOW TO GET THE BUILDTRACK APK (about 10 minutes, no software to install)
1. Make a free account at github.com and create a new repository (any name).
2. In the repository choose "Add file" > "Upload files". Unzip this folder first and drag in
   EVERYTHING inside it, including the hidden .github folder. Then press "Commit changes".
3. Open the "Actions" tab. The "Build APK" job starts by itself. Wait for the green tick (5 to 10 minutes).
4. Open that finished run and download "BuildTrack-apk" under Artifacts. Unzip it to get app-debug.apk.
5. Send app-debug.apk to your phone, tap it, and allow "install from unknown sources" when asked.
Note: this is a debug build for your own use. Publishing on Google Play needs a signed release build.
